package com.exemplo.sistema.service;

import com.exemplo.sistema.model.Matricula;
import com.exemplo.sistema.model.StatusMatricula;
import com.exemplo.sistema.repository.MatriculaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.util.List;

@Service
public class MatriculaService {
    @Autowired
    private MatriculaRepository matriculaRepository;

    public void salvar(Matricula matricula) {
        if (matricula.getAluno() == null || matricula.getAluno().getId() == null) {
            throw new IllegalArgumentException("O aluno informado é inválido.");
        }
        if (matricula.getCurso() == null || matricula.getCurso().getId() == null) {
            throw new IllegalArgumentException("O curso informado é inválido.");
        }
        if (matricula.getDataMatricula() == null) {
            matricula.setDataMatricula(LocalDate.now());
        }
        if (matricula.getId() == null) {
            matricula.setStatus(StatusMatricula.ATIVA);
        }
        if (matricula.getStatus() == StatusMatricula.ATIVA) {
            boolean jaAtiva = matriculaRepository.existsByAlunoAndCursoAndStatus(
                matricula.getAluno(), matricula.getCurso(), StatusMatricula.ATIVA
            );
            if (jaAtiva) {
                throw new IllegalArgumentException("O aluno já possui uma matrícula ativa neste curso.");
            }
        }
        matriculaRepository.save(matricula);
    }

    public List<Matricula> listarTodas() { return matriculaRepository.findAll(); }
    public Matricula buscarPorId(Long id) { return matriculaRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Matrícula não encontrada.")); }
    public void excluir(Long id) { matriculaRepository.deleteById(id); }
}
