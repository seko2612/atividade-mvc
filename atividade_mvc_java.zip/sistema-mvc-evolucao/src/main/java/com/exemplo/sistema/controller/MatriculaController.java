package com.exemplo.sistema.controller;

import com.exemplo.sistema.model.Matricula;
import com.exemplo.sistema.service.AlunoService;
import com.exemplo.sistema.service.CursoService;
import com.exemplo.sistema.service.MatriculaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/matriculas")
public class MatriculaController {
    @Autowired
    private MatriculaService matriculaService;
    @Autowired
    private AlunoService alunoService;
    @Autowired
    private CursoService cursoService;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("matriculas", matriculaService.listarTodas());
        return "matricula/lista";
    }

    @GetMapping("/novo")
    public String formularioNovo(Model model) {
        model.addAttribute("matricula", new Matricula());
        model.addAttribute("alunos", alunoService.listarTodos());
        model.addAttribute("cursos", cursoService.listarTodos());
        return "matricula/formulario";
    }

    @PostMapping("/salvar")
    public String salvar(Matricula matricula) {
        matriculaService.salvar(matricula);
        return "redirect:/matriculas";
    }

    @PostMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id) {
        matriculaService.excluir(id);
        return "redirect:/matriculas";
    }
}
