package com.exemplo.sistema.service;

import com.exemplo.sistema.model.Aluno;
import com.exemplo.sistema.repository.AlunoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class AlunoService {
    @Autowired
    private AlunoRepository alunoRepository;

    public void salvar(Aluno aluno) {
        if (aluno.getRg() == null || aluno.getRg().trim().isEmpty()) {
            throw new IllegalArgumentException("O campo RG é obrigatório.");
        }
        Optional<Aluno> alunoExistente = alunoRepository.findByRg(aluno.getRg());
        if (alunoExistente.isPresent()) {
            if (aluno.getId() == null || !alunoExistente.get().getId().equals(aluno.getId())) {
                throw new IllegalArgumentException("Já existe um aluno cadastrado com este RG.");
            }
        }
        alunoRepository.save(aluno);
    }

    public List<Aluno> listarTodos() { return alunoRepository.findAll(); }
    public Aluno buscarPorId(Long id) { return alunoRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Aluno não encontrado.")); }
    public void excluir(Long id) { alunoRepository.deleteById(id); }
}
