package com.exemplo.sistema.controller;

import com.exemplo.sistema.model.Curso;
import com.exemplo.sistema.service.CursoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/cursos")
public class CursoController {
    @Autowired
    private CursoService cursoService;

    @GetMapping
    public String listar(Model model) {
        model.addAttribute("cursos", cursoService.listarTodos());
        return "curso/lista";
    }

    @GetMapping("/novo")
    public String formularioNovo(Model model) {
        model.addAttribute("curso", new Curso());
        return "curso/formulario";
    }

    @PostMapping("/salvar")
    public String salvar(Curso curso) {
        cursoService.salvar(curso);
        return "redirect:/cursos";
    }

    @GetMapping("/editar/{id}")
    public String formularioEditar(@PathVariable Long id, Model model) {
        model.addAttribute("curso", cursoService.buscarPorId(id));
        return "curso/formulario";
    }

    @PostMapping("/excluir/{id}")
    public String excluir(@PathVariable Long id) {
        cursoService.excluir(id);
        return "redirect:/cursos";
    }
}
